<?php
App::uses('AppController', 'Controller');
/**
 * Reports Controller
 *
 * @property User $User
 */
class ReportsController extends AppController {
	
	public $uses = array();

/**
 * index method
 *
 * @return void
 */
	public function index() {
		
	}

}
