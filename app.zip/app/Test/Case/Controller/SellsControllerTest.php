<?php
App::uses('SellsController', 'Controller');

/**
 * SellsController Test Case
 *
 */
class SellsControllerTest extends ControllerTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.sell',
		'app.customers',
		'app.users',
		'app.product',
		'app.categories',
		'app.unities',
		'app.order',
		'app.supliers',
		'app.orders_product',
		'app.sells_product'
	);

/**
 * testIndex method
 *
 * @return void
 */
	public function testIndex() {
	}

/**
 * testView method
 *
 * @return void
 */
	public function testView() {
	}

/**
 * testAdd method
 *
 * @return void
 */
	public function testAdd() {
	}

/**
 * testEdit method
 *
 * @return void
 */
	public function testEdit() {
	}

}
